import{U as a,C as n}from"./index-CoGG49wX.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
